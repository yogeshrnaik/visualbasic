
#ifndef _PDFERROR_INCLUDED
#define _PDFERROR_INCLUDED

typedef enum TPDFErrorCode
{
// PDF general codes.
PDF_S_SUCCESS       =   0x00000000,     // The operation was completed successfully.
PDF_E_FATAL         =   0x8041ffff,     // Unknown fatal error.

// PDF stream module.
PDF_E_FILEOPEN      =   0x80410001,     // The file couldn't be opened.
PDF_E_FILECREATE    =   0x80410002,     // The file couldn't be created.
PDF_E_SETPOS        =   0x80410003,     // The read / write position pointer couldn't be set.

// PDF file module.
PDF_E_HEADER        =   0x80410010,     // The PDF header was not found.
PDF_E_EOF           =   0x80410011,     // The PDF end of file mark was not found.
PDF_E_XREF          =   0x80410012,     // The xref table contains an error.
PDF_E_TRAILER       =   0x80410013,     // The trailer dictionary is missing or invalid.
PDF_E_ROOT          =   0x80410014,     // The root object was not found.
PDF_E_PASSWORD      =   0x80410015,     // The authentication failed due to a wrong password.
PDF_E_CORRUPT       =   0x80410016,     // The file is corrupt and cannot be repaired. 

// PDF parser module.
PDF_E_OBJNO         =   0x80410021,     // The object number is missing.
PDF_E_GENNO         =   0x80410022,     // The generation number is missing.
PDF_E_IDENTITY      =   0x80410023,     // The object's identity doesn't match with the reference's.
PDF_E_OBJ           =   0x80410024,     // The "obj" keyword is missing.
PDF_E_NULL          =   0x80410025,     // The object is empty (null).
PDF_E_LENGTH        =   0x80410026,     // The "Length" attribute of the stream object is wrong.
PDF_E_ENDSTREAM     =   0x80410027,     // The "endstream" keyword is missing.
PDF_E_ENDOBJ        =   0x80410028,     // The "endobj" keyword is missing.

// PDF document module.
PDF_E_PAGE          =   0x80410031,     // The page doesn't exist (null).
PDF_E_PAGETYPE      =   0x80410032,     // The page has a missing or invalid "Type" attribute.
PDF_E_PAGEKIDS      =   0x80410033,     // The page has a missing or invalid "Kids" attribute.
PDF_E_PAGECOUNT     =   0x80410034,     // The page has a missing or invalid "Count" attribute.
PDF_E_PAGEPARENT    =   0x80410035,     // The page has a missing or invalid "Parent" attribute.
PDF_E_PAGERES       =   0x80410036,     // The page has a missing or invalid "Resource" attribute.
PDF_E_PAGEMEDIABOX  =   0x80410037,     // The page has a missing or invalid "MediaBox" attribute.
} TPDFErrorCode;

#endif // _PDFERROR_INCLUDED

