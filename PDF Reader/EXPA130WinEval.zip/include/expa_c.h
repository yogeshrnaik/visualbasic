/*
    File:         expa_c.h
    Copyright:    PDF-Tools AG, Switzerland (www.pdf-tools.com)
    Description:  C/C++ API definition for the PDF export tool (EXPA)
*/
#ifndef __EXPA_H_
#define __EXPA_H_

#include "pdferror.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifndef EXPAEXPORT
#  ifdef WIN32
#  define EXPAEXPORT __declspec(dllexport)
#  else
#  define EXPAEXPORT
#  endif
#endif

#ifndef EXPACALL
#  ifdef WIN32
#    define EXPACALL __stdcall
#  else
#    define EXPACALL
#  endif
#endif

/** \defgroup types Type definitions
 * @{
 */

  /** document handle type @see \ref document */
typedef struct SExpaDocumentData*   TExpaDocument;
/** page handle type @see \ref page */
typedef struct SExpaPageData*       TExpaPage;
/** content handle type @see \ref content */
typedef struct SExpaContentData*    TExpaContent;
/** text handle type @see \ref text */
typedef struct SExpaTextData*       TExpaText;
/** font handle type @see \ref font */
typedef struct SExpaFontData*       TExpaFont;
/** color space handle type @see \ref cs */
typedef struct SExpaColorSpaceData* TExpaColorSpace;
/** color space handle type @see \ref gs */
typedef struct SExpaGSData*         TExpaGraphicsState;
/** image handle type @see \ref image */
typedef struct SExpaImageData*      TExpaImage;

/** data structure representing a rectangle area in PDF coordinates */
typedef struct SExpaRectangle
{
  float fLeft;
  float fBottom;
  float fRight;
  float fTop;
} TExpaRectangle;

/** orientation enumeration type */
typedef enum TExpaOrientation {
    eOrientationTopLeft = 1, eOrientationTopRight = 2, eOrientationBottomRight = 3, eOrientationBottomLeft = 4,
    eOrientationLeftTop = 5, eOrientationRightTop = 6, eOrientationRightBottom = 7, eOrientationLeftBottom = 8
} TExpaOrientation;

/** data structure representing a PDF text matrix */
typedef struct SExpaTransformMatrix
{
  float fA, fB, fC, fD, fE, fF;
  float fSkewX;
  float fSkewY;
  float fRotation;
  int   iOrientation;
} TExpaTransformMatrix;

/** data structure giving access to binary stream data */
typedef struct SExpaStreamData
{
  unsigned char* sData;
  long  nLength;
} TExpaStreamData;

/** enumeration for the different types of information stored on a PDF page */
typedef enum TExpaContentObjectType
{
  eNone, eText, eImage, ePath
} TExpaContentObjectType;


/** bit set type, used for example to store the permission flags controlling document security */
typedef unsigned int TExpaBitset;

/** structure representing a date and time of day (e.g. CreationDate) */
typedef struct SExpaDate
{
    short iYear;   /**< year 1900..2100 */
    short iMonth ; /**< 1..12 */
    short iDay;    /**< 1..31 */
    short iHour;   /**< 0..23 */
    short iMinute; /**< 0..59 */
    short iSecond; /**< 0..59 */
    signed short iUtcOffset; /**< time zone information, offset to UTC in minutes */
} TExpaDate;

  /** @}
 * \defgroup api API initialization and termination functions
 * @{
 */

/** this function must be called before using any other functions of the API */
EXPAEXPORT void EXPACALL ExpaInitializeAPI();
/** call this function to free resources allocated during InitializeAPI */
EXPAEXPORT void EXPACALL ExpaUnInitializeAPI();

/************************** document related calls *****************************/
/** @}
 * \defgroup document Document related functions
 * @{
 */

/** create a document object */
EXPAEXPORT TExpaDocument EXPACALL ExpaCreateDocument();

/** dispose the document object */
EXPAEXPORT void EXPACALL ExpaDestroyDocument(TExpaDocument);

/** open a PDF file for data extraction;
 * @return non-zero on success */
EXPAEXPORT int EXPACALL ExpaDocOpen(TExpaDocument,
                                    const char* szFilename, const char* szPassword);
EXPAEXPORT int EXPACALL ExpaDocOpenW(TExpaDocument,
                                    const unsigned short* pFilename, const char* szPassword);
EXPAEXPORT int EXPACALL ExpaDocOpenMem(TExpaDocument,
                                       const unsigned char* pDocumentBytes, long nDocumentLength,
                                       const char* szPassword);

/** close the document and free all associated resources;
 * multiple Open/Close calls are permitted */
EXPAEXPORT int EXPACALL ExpaDocClose(TExpaDocument);

EXPAEXPORT TPDFErrorCode ExpaDocGetLastError(TExpaDocument);

/** return non-zero if document is encrypted */
EXPAEXPORT int         EXPACALL ExpaDocIsEncrypted(TExpaDocument);
EXPAEXPORT int         EXPACALL ExpaDocGetMajorVersion(TExpaDocument);
EXPAEXPORT int         EXPACALL ExpaDocGetMinorVersion(TExpaDocument);
EXPAEXPORT const char* EXPACALL ExpaDocGetTitle(TExpaDocument);
EXPAEXPORT const unsigned short* EXPACALL ExpaDocGetTitleW(TExpaDocument);
EXPAEXPORT const char* EXPACALL ExpaDocGetAuthor(TExpaDocument);
EXPAEXPORT const unsigned short* EXPACALL ExpaDocGetAuthorW(TExpaDocument doc);
EXPAEXPORT const char* EXPACALL ExpaDocGetSubject(TExpaDocument);
EXPAEXPORT const unsigned short* EXPACALL ExpaDocGetSubjectW(TExpaDocument);
EXPAEXPORT const char* EXPACALL ExpaDocGetKeywords(TExpaDocument);
EXPAEXPORT const unsigned short* EXPACALL ExpaDocGetKeywordsW(TExpaDocument);
EXPAEXPORT int         EXPACALL ExpaDocGetModDate(TExpaDocument,TExpaDate* pDate);
EXPAEXPORT int         EXPACALL ExpaDocGetCreationDate(TExpaDocument, TExpaDate* pDate);
EXPAEXPORT const char* EXPACALL ExpaDocGetInfoEntry(TExpaDocument, const char* szKey);
EXPAEXPORT const unsigned short* EXPACALL ExpaDocGetInfoEntryW(TExpaDocument, const char* szKey);

/** return the number of pages in the document */
EXPAEXPORT long        EXPACALL ExpaDocPageCount(TExpaDocument);
/** acquire the specified page for data extraction. @return non-zero on success */
EXPAEXPORT int         EXPACALL ExpaDocSetPageNo(TExpaDocument, long iPageNo);
/** return the current page number */
EXPAEXPORT long        EXPACALL ExpaDocGetPageNo(TExpaDocument);
EXPAEXPORT TExpaPage   EXPACALL ExpaDocGetPage(TExpaDocument);

/************************** page related calls *****************************/
/** @}
 * \defgroup page Page related functions
 * @{ */
EXPAEXPORT TExpaDocument   EXPACALL ExpaPageGetDocument(TExpaPage);
EXPAEXPORT TExpaRectangle* EXPACALL ExpaPageGetMediaBox(TExpaPage);
EXPAEXPORT TExpaRectangle* EXPACALL ExpaPageGetCropBox(TExpaPage);
EXPAEXPORT int             EXPACALL ExpaPageGetRotate(TExpaPage);
EXPAEXPORT TExpaContent    EXPACALL ExpaPageGetContent(TExpaPage);


/************************** content related calls *****************************/
/** @}
 * \defgroup content       Content related functions
 * @{ */
EXPAEXPORT void               EXPACALL ExpaContentResetContent(TExpaContent, int iBoolIncludeRotate);
EXPAEXPORT TExpaGraphicsState EXPACALL ExpaContentGetGraphicsState(TExpaContent);
EXPAEXPORT TExpaText          EXPACALL ExpaContentGetText(TExpaContent);
EXPAEXPORT TExpaImage         EXPACALL ExpaContentGetImage(TExpaContent);
EXPAEXPORT SExpaStreamData*   EXPACALL ExpaContentGetPath(TExpaContent);
EXPAEXPORT void               EXPACALL ExpaContentSetBreakWords(TExpaContent, int iBoolOn);
EXPAEXPORT TExpaText          EXPACALL ExpaContentGetNextText(TExpaContent);
EXPAEXPORT int                EXPACALL ExpaContentGetNextImage(TExpaContent);
EXPAEXPORT int                EXPACALL ExpaContentGetNextPath(TExpaContent);
EXPAEXPORT TExpaContentObjectType EXPACALL ExpaContentGetNextObject(TExpaContent);

/************************** text related calls *****************************/
/** @}
 * \defgroup text       Text extraction related functions
 * @{ */
/** @return the raw character string */
EXPAEXPORT SExpaStreamData*      EXPACALL ExpaTextGetRawString(TExpaText);
/** @return the number of characters contained in the text string */
EXPAEXPORT int                   EXPACALL ExpaTextGetStringLength(TExpaText);
/** @return the unicode string, having possibly more than GetStringLength() elements, and terminated with 0x0000 */
EXPAEXPORT const unsigned short* EXPACALL ExpaTextGetUnicodeString(TExpaText);
EXPAEXPORT const float*          EXPACALL ExpaTextGetNextXPos(TExpaText);
EXPAEXPORT TExpaTransformMatrix* EXPACALL ExpaTextGetTextMatrix(TExpaText);

/************************** font related calls *****************************/
/** @}
 * \defgroup font       Font related functions
 * @{ */
EXPAEXPORT const char*    EXPACALL ExpaFontGetType(TExpaFont);
EXPAEXPORT const char*    EXPACALL ExpaFontGetBaseName(TExpaFont);
/** return the index of the first character of the font */
EXPAEXPORT int            EXPACALL ExpaFontGetFirstChar(TExpaFont);
/** return the index of the last character of the font */
EXPAEXPORT int            EXPACALL ExpaFontGetLastChar(TExpaFont);
/** return the character widths of the font
  * there are 256 elements in the array that can directly be indexed with the (unsigned) raw string character number  */
EXPAEXPORT const float*   EXPACALL ExpaFontGetWidths(TExpaFont);
/** @return the glyph name of each character with CharIndex running from 0 to LastChar-FirstChar */
EXPAEXPORT const char*    EXPACALL ExpaFontGetEncoding(TExpaFont, int iCharIndex);
EXPAEXPORT TExpaBitset    EXPACALL ExpaFontGetFlags(TExpaFont);
/** @return the bounding box as array of four floats */
EXPAEXPORT const float*   EXPACALL ExpaFontGetBBox(TExpaFont);
EXPAEXPORT float          EXPACALL ExpaFontGetItalicAngle(TExpaFont);
EXPAEXPORT float          EXPACALL ExpaFontGetAscent(TExpaFont);
EXPAEXPORT float          EXPACALL ExpaFontGetDescent(TExpaFont);
EXPAEXPORT float          EXPACALL ExpaFontGetCapHeight(TExpaFont);
EXPAEXPORT float          EXPACALL ExpaFontGetStemV(TExpaFont);
EXPAEXPORT float          EXPACALL ExpaFontGetStemH(TExpaFont);
EXPAEXPORT float          EXPACALL ExpaFontGetAvgWidth(TExpaFont);
EXPAEXPORT float          EXPACALL ExpaFontGetMaxWidth(TExpaFont);
EXPAEXPORT float          EXPACALL EXPACALL ExpaFontGetMissingWidth(TExpaFont);
EXPAEXPORT const char*    EXPACALL ExpaFontGetCharSet(TExpaFont);
EXPAEXPORT int            EXPACALL ExpaFontGetFontFileType(TExpaFont);
EXPAEXPORT TExpaStreamData*EXPACALL ExpaFontGetFontFile(TExpaFont);

/************************** image related calls *****************************/
/** @}
 * \defgroup image       Image related functions
 * @{ */
EXPAEXPORT long             EXPACALL ExpaImageGetWidth(TExpaImage);
EXPAEXPORT long             EXPACALL ExpaImageGetHeight(TExpaImage);
EXPAEXPORT long             EXPACALL ExpaImageGetBitsPerComponent(TExpaImage);
EXPAEXPORT TExpaStreamData* EXPACALL ExpaImageGetSamples(TExpaImage);
EXPAEXPORT TExpaStreamData* EXPACALL ExpaImageGetMask(TExpaImage);
EXPAEXPORT TExpaColorSpace  EXPACALL ExpaImageGetColorSpace(TExpaImage);                        /**< return color space information for the image */
EXPAEXPORT int              EXPACALL ExpaImageConvertToRGB(TExpaImage);                         /**< convert image to RGB; @return non-zero on success; BitsPerComponent must be >= 8 */
EXPAEXPORT int              EXPACALL ExpaImageChangeOrientation(TExpaImage, TExpaOrientation);  /**< change to image according to the specified orientation */
EXPAEXPORT int              EXPACALL ExpaImageStore(TExpaImage, const char* szPath);            /**< store image in a TIFF file; returns non-zero on success */
EXPAEXPORT int              EXPACALL ExpaImageStoreW(TExpaImage, const unsigned short* szPath); /**< store image in a TIFF file; returns non-zero on success */
/************************** color space related calls ************************/
/** @}
 * \defgroup cs       Color Space related functions
 * @{ */
EXPAEXPORT int              EXPACALL ExpaCSGetComponentsPerPixel(TExpaColorSpace); /**< return the number of components per pixel; for RGB images, this will be 3; for CMYK images: 4 */
EXPAEXPORT TExpaColorSpace  EXPACALL ExpaCSGetBaseColorSpace(TExpaColorSpace);
EXPAEXPORT int              EXPACALL ExpaCSIsIndexed(TExpaColorSpace);           /**< return non-zero if the color space is indexed (if there is a palette) */
EXPAEXPORT int              EXPACALL ExpaCSGetHighIndex(TExpaColorSpace);        /**< return the number of index values minus 1 */

/** @return the colorspace lookup data (palette)
  * length is (HighIndex+1)*ComponentsPerPixel */
EXPAEXPORT const unsigned char* EXPACALL ExpaCSGetLookup(TExpaColorSpace);
EXPAEXPORT const char*    EXPACALL ExpaCSGetName(TExpaColorSpace);

/************************** graphics space related calls **********************/
/** @}
 * \defgroup gs       Graphics State related functions
 * @{ */
EXPAEXPORT TExpaTransformMatrix* EXPACALL ExpaGSGetCTM(TExpaGraphicsState);
EXPAEXPORT TExpaColorSpace EXPACALL ExpaGSGetStrokeColorSpace(TExpaGraphicsState);
EXPAEXPORT TExpaColorSpace EXPACALL ExpaGSGetFillColorSpace(TExpaGraphicsState);
EXPAEXPORT long     EXPACALL ExpaGSGetStrokeColorRGB(TExpaGraphicsState);
EXPAEXPORT long     EXPACALL ExpaGSGetFillColorRGB(TExpaGraphicsState);
EXPAEXPORT long     EXPACALL ExpaGSGetStrokeColorCMYK(TExpaGraphicsState);
EXPAEXPORT long     EXPACALL ExpaGSGetFillColorCMYK(TExpaGraphicsState);
EXPAEXPORT float    EXPACALL ExpaGSGetCharSpacing(TExpaGraphicsState);
EXPAEXPORT float    EXPACALL ExpaGSGetWordSpacing(TExpaGraphicsState);
EXPAEXPORT float    EXPACALL ExpaGSGetHorizontalScaling(TExpaGraphicsState);
EXPAEXPORT float    EXPACALL ExpaGSGetLeading(TExpaGraphicsState);
EXPAEXPORT TExpaFont EXPACALL ExpaGSGetFont(TExpaGraphicsState);
EXPAEXPORT float    EXPACALL ExpaGSGetFontSize(TExpaGraphicsState);
EXPAEXPORT int      EXPACALL ExpaGSGetTextRenderingMode(TExpaGraphicsState);
EXPAEXPORT float    EXPACALL ExpaGSGetTextRise(TExpaGraphicsState);
EXPAEXPORT int      EXPACALL ExpaGSGetTextKnockout(TExpaGraphicsState);
EXPAEXPORT float    EXPACALL ExpaGSGetLineWidth(TExpaGraphicsState);
EXPAEXPORT short    EXPACALL ExpaGSGetLineCap(TExpaGraphicsState);
EXPAEXPORT short    EXPACALL ExpaGSGetLineJoin(TExpaGraphicsState);
EXPAEXPORT float    EXPACALL ExpaGSGetMiterLimit(TExpaGraphicsState);
EXPAEXPORT float    EXPACALL ExpaGSGetDashPhase(TExpaGraphicsState);

/** @return the number of elements in the dash array */
EXPAEXPORT int      EXPACALL ExpaGSGetDashSize(TExpaGraphicsState);

/** retrieve the dash array elements;
 * @param fDashArray the area for storing the dash array elements
 * @param nAllocatedElements the maximum number of elements that can be stored
 * @return the number of elements actually stored 
 */
EXPAEXPORT int      EXPACALL ExpaGSGetDashArray(TExpaGraphicsState, float fDashArray[], int nAllocatedElements);

 /** @} */

#ifdef __cplusplus
}
#endif

#endif
