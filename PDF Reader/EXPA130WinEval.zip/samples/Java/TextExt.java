/****************************************************************************
 *
 * File:            TextExt.java
 *
 * Usage:           java TextExt PDF-InputFile
 *
 * Description:     Prints out the text of PDF-InputFile.
 *
 * Version:         1.01  (23-Jul-2004)
 *
 * Author:          Philip Renggli, PDF Tools AG   
 * 
 * Copyright:       Copyright (C) 2004 PDF Tools AG, Switzerland
 *                  Permission to use, copy, modify, and distribute this
 *                  software and its documentation for any purpose and without
 *                  fee is hereby granted, provided that the above copyright
 *                  notice appear in all copies and that both that copyright
 *                  notice and this permission notice appear in supporting
 *                  documentation.  This software is provided "as is" without
 *                  express or implied warranty.
 *
 ***************************************************************************/

import com.pdftools.expa.*;

public class TextExt {

public static void main(String[] args) {
    try {
        // open input file
        Document thePDF = new Document(args[0], "");
        
        // loop through all pages
        for(long curPage = 1; curPage <= thePDF.getPageCount(); curPage++)
        {
            // set the page number
            thePDF.setPage(curPage);

            // get the content
            Content theContent = thePDF.getPage().getContent();
            
            // extract words
            theContent.reset(true);
            theContent.reset();

            // loop through all text tokens on the page
            System.out.println("Begin Page " + curPage + " of " + thePDF.getPageCount());            
            while(theContent.getNextText())
            {
                System.out.println(theContent.getText().getUnicodeString());
            }
        }

    } catch (Throwable e) {
        e.printStackTrace();
    }
}
}
