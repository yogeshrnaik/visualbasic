saving project
obs trigger page
adding observations
blank solution
different layouts of project review screen
scrolling to top of frame while moving to prev or next
thumbnails added to three layouts of Review sheet
all insights page ready
filter on DFS sheet
all solution page done - but not loading properly

