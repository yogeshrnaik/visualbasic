========================================================================
       KONSOLENANWENDUNG : comparser
========================================================================


Diese comparser-Anwendung hat der Anwendungs-Assistent f�r Sie erstellt.  

Diese Datei enth�lt eine Zusammenfassung dessen, was Sie in jeder der Dateien
finden, die Ihre comparser-Anwendung bilden.

comparser.dsp
    Diese Datei (Projektdatei) enth�lt Informationen auf Projektebene und wird zur
    Erstellung eines einzelnen Projekts oder Teilprojekts verwendet. Andere Benutzer k�nnen
    die Projektdatei (.dsp) gemeinsam nutzen, sollten aber die Makefiles lokal exportieren.

comparser.cpp
    Dieses ist die Hauptquellcodedatei der Anwendung.


/////////////////////////////////////////////////////////////////////////////
Weitere Standarddateien:

StdAfx.h, StdAfx.cpp
    Diese Dateien werden zum Erstellen einer vorkompilierten Header-Datei (PCH) namens
    comparser.pch und einer vorkompilierten Typdatei namens StdAfx.obj verwendet.


/////////////////////////////////////////////////////////////////////////////
Weitere Hinweise:

Der Anwendungs-Assistent verwendet "ZU ERLEDIGEN:", um Bereiche des Quellcodes zu
kennzeichnen, die Sie hinzuf�gen oder anpassen sollten.

/////////////////////////////////////////////////////////////////////////////
